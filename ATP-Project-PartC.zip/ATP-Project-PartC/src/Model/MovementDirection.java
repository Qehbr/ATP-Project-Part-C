package Model;

public enum MovementDirection {
    UP, DOWN, LEFT, RIGHT
}
